<?php
    // kode anda
    $conn = mysqli_connect("127.0.0.1", "root", "", "php2") or die("Unconnection");

?>