<?php
    // kode anda
    $conn = mysqli_connect("127.0.0.1", "root", "", "bakery_71220855") or die("Unconnection");

?>