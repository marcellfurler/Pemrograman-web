<?php  
if ($_POST) {

    echo "Selamat, $name<br>";
    echo "Email: $email<br>";
    echo "Pekerjaan: $job<br>";
    echo "Total Semesters: $totalSemesters<br>";
}
?>